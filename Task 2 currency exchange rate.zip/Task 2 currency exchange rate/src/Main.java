import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        System.out.print("Пожалуйста введите имеющуюся у вас сумму в рублях для её конвертации в другие валюты: ");
        Scanner scan = new Scanner(System.in);
        double usercash = scan.nextDouble();
        double dollar = 97.05, euro = 105.22, yuan = 13.59, yen = 0.633216, peso = 0.09817, convertedcash;
        convertedcash = usercash / dollar;
        System.out.println("Имеющаяся у вас сумма в долларах равна: " + convertedcash);
        convertedcash = usercash / euro;
        System.out.println("Имеющаяся у вас сумма в евро равна: " + convertedcash);
        convertedcash = usercash / yuan;
        System.out.println("Имеющаяся у вас сумма в Китайских юань равна: " + convertedcash);
        convertedcash = usercash / yen;
        System.out.println("Имеющаяся у вас сумма в Японских йен равна: " + convertedcash);
        convertedcash = convertedcash / peso;
        System.out.println("Имеющаяся у вас сумма в Аргентинских песо равна: " + convertedcash);
    }
}