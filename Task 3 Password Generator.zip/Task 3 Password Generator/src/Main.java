import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Random rand = new Random();
        Scanner scan = new Scanner(System.in);
        String chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890!@#$%^&*()_+-/.,<>?;':\"{}\\ []|`~";
        System.out.println("Ведите размер пароля");
        int uservoice = scan.nextInt();
        int passwordlength=0;
        while (passwordlength<=uservoice){
            int index = rand.nextInt(chars.length());
            char password = chars.charAt(index);
            System.out.print(password);
            passwordlength++;
        }
    }
}