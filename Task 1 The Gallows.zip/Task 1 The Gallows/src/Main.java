import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan= new Scanner(System.in) ;
        Random rand= new Random() ;
        int num = rand.nextInt(3);
        System.out.println(num);
        String riddle1 = "_";
        String riddle2 = "_";
        String riddle3 = "_";
        String riddle4 = "_";
        String riddle5 = "_";
        String riddle6 = "_";
        int live = 5;
        String  put= "put";
        String  boat= "boat";
        String sea = "sea";
        if(num==0) {
            while (live != 0) {
                if (riddle1.charAt(0) == put.charAt(0) && riddle2.charAt(0) == put.charAt(1) && riddle3.charAt(0) == put.charAt(2)) {
                    System.out.println("Поздравляю с победой!");
                    break;
                }
                System.out.print("Загадайте букву:");
                String speakuser = scan.nextLine();
                if (speakuser.charAt(0) == put.charAt(0)) {
                    riddle1 = speakuser;
                    System.out.println(riddle1 + riddle2 + riddle3);
                    System.out.println("Осталось жизней до висельницы:" + live);
                } else if (speakuser.charAt(0) == put.charAt(1)) {
                    riddle2 = speakuser;
                    System.out.println(riddle1 + riddle2 + riddle3);
                    System.out.println("Осталось жизней до висельницы:" + live);
                } else if (speakuser.charAt(0) == put.charAt(2)) {
                    riddle3 = speakuser;
                    System.out.println(riddle1 + riddle2 + riddle3);
                    System.out.println("Осталось жизней до висельницы:" + live);
                } else {
                    live--;
                    System.out.println("Такой буквы в слове нет.");
                    System.out.println("Осталось жизней до висельницы:" + live);
                }
            }
        } else if (num==1) {
            while (live != 0) {
                if (riddle1.charAt(0) == boat.charAt(0) && riddle2.charAt(0) == boat.charAt(1) && riddle3.charAt(0) == boat.charAt(2) && riddle4.charAt(0) == boat.charAt(3)){
                    System.out.println("Поздравляю с победой!");
                    break;
                }
                System.out.print("Загадайте букву:");
                String speakuser = scan.nextLine();
                if (speakuser.charAt(0) == boat.charAt(0)) {
                    riddle1 = speakuser;
                    System.out.println(riddle1 + riddle2 + riddle3 + riddle4);
                    System.out.println("Осталось жизней до висельницы:" + live);
                } else if (speakuser.charAt(0) == boat.charAt(1)) {
                    riddle2 = speakuser;
                    System.out.println(riddle1 + riddle2 + riddle3 + riddle4);
                    System.out.println("Осталось жизней до висельницы:" + live);
                } else if (speakuser.charAt(0) == boat.charAt(2)) {
                    riddle3 = speakuser;
                    System.out.println(riddle1 + riddle2 + riddle3 + riddle4);
                    System.out.println("Осталось жизней до висельницы:" + live);
                }else if (speakuser.charAt(0) == boat.charAt(3)) {
                    riddle4 = speakuser;
                    System.out.println(riddle1 + riddle2 + riddle3 + riddle4);
                    System.out.println("Осталось жизней до висельницы:" + live);
                } else {
                    live--;
                    System.out.println("Такой буквы в слове нет.");
                    System.out.println("Осталось жизней до висельницы:" + live);
                }
            }
        } else if (num==2) {
            while (live != 0) {
                if (riddle1.charAt(0) == sea.charAt(0) && riddle2.charAt(0) == sea.charAt(1) && riddle3.charAt(0) == sea.charAt(2)) {
                    System.out.println("Поздравляю с победой!");
                    break;
                }
                System.out.print("Загадайте букву:");
                String speakuser = scan.nextLine();
                if (speakuser.charAt(0) == sea.charAt(0)) {
                    riddle1 = speakuser;
                    System.out.println(riddle1 + riddle2 + riddle3);
                    System.out.println("Осталось жизней до висельницы:" + live);
                } else if (speakuser.charAt(0) == sea.charAt(1)) {
                    riddle2 = speakuser;
                    System.out.println(riddle1 + riddle2 + riddle3);
                    System.out.println("Осталось жизней до висельницы:" + live);
                } else if (speakuser.charAt(0) == sea.charAt(2)) {
                    riddle3 = speakuser;
                    System.out.println(riddle1 + riddle2 + riddle3);
                    System.out.println("Осталось жизней до висельницы:" + live);
                } else {
                    live--;
                    System.out.println("Такой буквы в слове нет.");
                    System.out.println("Осталось жизней до висельницы:" + live);
                }
            }
        }
    }
}